#!/usr/bin/env bash
rm -rf re-bilingual-1.0.0.tgz
npm pack ../
scp re-bilingual-1.0.0.tgz root@chat.akronenglish1.com:~
scp provisionRe-bilingual.sh root@chat.akronenglish1.com:~
ssh root@chat.akronenglish1.com "chmod 500 ./provisionRe-bilingual.sh; ./provisionRe-bilingual.sh"